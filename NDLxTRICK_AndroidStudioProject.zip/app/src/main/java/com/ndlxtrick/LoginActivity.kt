package com.ndlxtrick

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        // Giả lập đăng nhập, tự vào Home
        startActivity(Intent(this, HomeActivity::class.java))
        finish()
    }
}
